# Gruvbox Wallpapers
A place where to find gruvbox theme wallpapers.
[https://gruvbox-wallpapers.pages.dev/](https://gruvbox-wallpapers.pages.dev/ 'Gruvbox Wallpapers')
## Contributions

1. Fork the project.
2. Add the wallpapers that you have in their respective folder.
3. Make a pull request.

IMPORTANT: avoid spaces in names!!!

If your wallpaper does not fit in any of the folders we can debate the creation of a new one.

I tend to accept any contributions, but let's keep the site with images that match or look good with the gruvbox's color scheme :').
